Before playing, please install the "Jelly" font located in the "fonts" folder.

How to Play:
1. Tap to start the level. The shape will begin to grow.
2. Stop the shape when it is within the black border.
3. Tap to move on to the next level if you win, or tap to restart if you lose.

By Phillip Nadjafov and Harrison Apitz-Grossman